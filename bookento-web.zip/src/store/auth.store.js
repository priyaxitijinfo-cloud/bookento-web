import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";

import { AUTH_CONFIG } from "@/config/app.config";
import { USER_ROLES } from "@/constants/status.constants";
import { mockAuthSessions, VALID_OTP } from "@/mock/auth";
import { currentProvider } from "@/mock/providers";
import { currentUser } from "@/mock/users";
import { clearAuthCookie, createMockToken, setAuthCookie } from "@/utils/format.utils";
import { delay } from "@/mock/helpers";

export const useAuthStore = create(
  devtools(
    persist(
      (set, get) => ({
        user: null,
        isAuthenticated: false,
        isLoading: false,
        isGuest: false,
        registrationDraft: { step: 1 },

        login: async (email, password, role = USER_ROLES.USER) => {
          set({ isLoading: true });
          await delay(800);

          const session =
            role === USER_ROLES.PROVIDER
              ? { ...mockAuthSessions.provider, email, status: "approved" }
              : { ...mockAuthSessions.user, email };

          const token = createMockToken({
            sub: session.id,
            role: session.role,
            status: session.status || "approved",
            email,
          });

          setAuthCookie(AUTH_CONFIG.accessTokenCookie, token, AUTH_CONFIG.accessTokenMaxAge);

          set({
            user: session,
            isAuthenticated: true,
            isGuest: false,
            isLoading: false,
          });

          return { success: true, user: session };
        },

        loginAsGuest: async () => {
          set({ isLoading: true });
          await delay(400);
          set({
            user: mockAuthSessions.guest,
            isAuthenticated: true,
            isGuest: true,
            isLoading: false,
          });
          return { success: true };
        },

        logout: async () => {
          await delay(300);
          clearAuthCookie(AUTH_CONFIG.accessTokenCookie);
          clearAuthCookie(AUTH_CONFIG.refreshTokenCookie);
          set({ user: null, isAuthenticated: false, isGuest: false });
        },

        verifyOtp: async (otp) => {
          set({ isLoading: true });
          await delay(600);
          const valid = VALID_OTP.includes(otp);
          set({ isLoading: false });
          return { success: valid, message: valid ? "OTP verified" : "Invalid OTP" };
        },

        updateRegistrationDraft: (data) => {
          set((state) => ({
            registrationDraft: { ...state.registrationDraft, ...data },
          }));
        },

        submitRegistration: async () => {
          set({ isLoading: true });
          await delay(1200);
          const token = createMockToken({
            sub: currentProvider.id,
            role: USER_ROLES.PROVIDER,
            status: "pending",
            email: get().registrationDraft.email,
          });
          setAuthCookie(AUTH_CONFIG.accessTokenCookie, token, AUTH_CONFIG.accessTokenMaxAge);
          set({
            user: { ...mockAuthSessions.provider, status: "pending" },
            isAuthenticated: true,
            isLoading: false,
          });
          return { success: true };
        },

        resetPassword: async () => {
          set({ isLoading: true });
          await delay(800);
          set({ isLoading: false });
          return { success: true };
        },

        forgotPassword: async () => {
          set({ isLoading: true });
          await delay(800);
          set({ isLoading: false });
          return { success: true };
        },
      }),
      {
        name: "bookento-auth",
        partialize: (state) => ({
          user: state.user,
          isAuthenticated: state.isAuthenticated,
          isGuest: state.isGuest,
          registrationDraft: state.registrationDraft,
        }),
      },
    ),
    { name: "AuthStore" },
  ),
);
