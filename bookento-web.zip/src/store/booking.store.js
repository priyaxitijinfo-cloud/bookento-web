import { create } from "zustand";
import { devtools } from "zustand/middleware";

const initialDraft = {
  providerId: "",
  visitType: null,
  serviceIds: [],
  packageId: null,
  branchId: null,
  addressId: null,
  scheduledDate: null,
  scheduledTime: null,
  paymentMethod: null,
};

export const useBookingStore = create(
  devtools(
    (set) => ({
      draft: initialDraft,
      currentStep: 0,
      isComplete: false,

      setProviderId: (id) => set((s) => ({ draft: { ...s.draft, providerId: id } })),
      setVisitType: (type) => set((s) => ({ draft: { ...s.draft, visitType: type } })),
      toggleService: (serviceId) =>
        set((s) => {
          const ids = s.draft.serviceIds.includes(serviceId)
            ? s.draft.serviceIds.filter((id) => id !== serviceId)
            : [...s.draft.serviceIds, serviceId];
          return { draft: { ...s.draft, serviceIds: ids, packageId: null } };
        }),
      setServices: (serviceIds) =>
        set((s) => ({ draft: { ...s.draft, serviceIds, packageId: null } })),
      setPackageId: (packageId) =>
        set((s) => ({ draft: { ...s.draft, packageId, serviceIds: [] } })),
      setBranchId: (branchId) => set((s) => ({ draft: { ...s.draft, branchId } })),
      setAddressId: (addressId) => set((s) => ({ draft: { ...s.draft, addressId } })),
      setScheduledDate: (date) => set((s) => ({ draft: { ...s.draft, scheduledDate: date } })),
      setScheduledTime: (time) => set((s) => ({ draft: { ...s.draft, scheduledTime: time } })),
      setPaymentMethod: (method) => set((s) => ({ draft: { ...s.draft, paymentMethod: method } })),
      setStep: (step) => set({ currentStep: step }),
      nextStep: () => set((s) => ({ currentStep: s.currentStep + 1 })),
      prevStep: () => set((s) => ({ currentStep: Math.max(0, s.currentStep - 1) })),
      completeBooking: () => set({ isComplete: true }),
      reset: () => set({ draft: initialDraft, currentStep: 0, isComplete: false }),
    }),
    { name: "BookingStore" },
  ),
);
