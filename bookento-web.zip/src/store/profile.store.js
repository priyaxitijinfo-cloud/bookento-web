import { create } from "zustand";
import { devtools, persist } from "zustand/middleware";

import { currentUser, userAddresses } from "@/mock/users";
import { providerSettings, userSettings } from "@/mock/settings";
import { delay } from "@/mock/helpers";

export const useProfileStore = create(
  devtools(
    persist(
      (set) => ({
        profile: currentUser,
        addresses: userAddresses,
        isLoading: false,

        updateProfile: async (data) => {
          set({ isLoading: true });
          await delay(600);
          set((s) => ({ profile: { ...s.profile, ...data }, isLoading: false }));
          return { success: true };
        },

        addAddress: async (address) => {
          await delay(400);
          const newAddr = { ...address, id: `addr_${Date.now()}`, userId: currentUser.id };
          set((s) => ({ addresses: [...s.addresses, newAddr] }));
          return newAddr;
        },
      }),
      { name: "bookento-profile" },
    ),
    { name: "ProfileStore" },
  ),
);

export const useSettingsStore = create(
  devtools(
    persist(
      (set) => ({
        userSettings,
        providerSettings,
        isLoading: false,

        updateUserSettings: async (data) => {
          set({ isLoading: true });
          await delay(400);
          set((s) => ({
            userSettings: { ...s.userSettings, ...data },
            isLoading: false,
          }));
        },

        updateProviderSettings: async (data) => {
          set({ isLoading: true });
          await delay(400);
          set((s) => ({
            providerSettings: { ...s.providerSettings, ...data },
            isLoading: false,
          }));
        },
      }),
      { name: "bookento-settings" },
    ),
    { name: "SettingsStore" },
  ),
);
