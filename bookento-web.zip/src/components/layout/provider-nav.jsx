"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  BarChart3, Building2, Calendar, Film, Home, Image, Layers,
  MessageCircle, Package, Settings, Star, Wallet, Wrench,
} from "lucide-react";

import { ROUTES } from "@/constants/routes.constants";
import { cn } from "@/lib/utils";
import { useUIStore } from "@/store";

const sidebarItems = [
  { href: ROUTES.PROVIDER_HOME, label: "Dashboard", icon: Home },
  { href: ROUTES.PROVIDER_APPOINTMENTS, label: "Appointments", icon: Calendar },
  { href: ROUTES.PROVIDER_EARNINGS, label: "Earnings", icon: Wallet },
  { href: ROUTES.PROVIDER_SERVICES, label: "Services", icon: Wrench },
  { href: ROUTES.PROVIDER_PACKAGES, label: "Packages", icon: Package },
  { href: ROUTES.PROVIDER_BRANCHES, label: "Branches", icon: Building2 },
  { href: ROUTES.PROVIDER_CATEGORIES, label: "Categories", icon: Layers },
  { href: ROUTES.PROVIDER_POSTS, label: "Posts", icon: Image },
  { href: ROUTES.PROVIDER_REELS, label: "Reels", icon: Film },
  { href: ROUTES.PROVIDER_RATINGS, label: "Ratings", icon: Star },
  { href: ROUTES.PROVIDER_CHATS, label: "Chats", icon: MessageCircle },
  { href: ROUTES.PROVIDER_ANALYTICS, label: "Analytics", icon: BarChart3 },
  { href: ROUTES.PROVIDER_SETTINGS, label: "Settings", icon: Settings },
];

export function ProviderSidebar() {
  const pathname = usePathname();
  const { isSidebarOpen, setSidebarOpen } = useUIStore();

  return (
    <>
      {isSidebarOpen && (
        <div className="fixed inset-0 z-40 bg-black/50 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
      <aside
        className={cn(
          "border-border bg-sidebar fixed inset-y-0 left-0 z-50 flex w-64 flex-col border-r transition-transform lg:static lg:translate-x-0",
          isSidebarOpen ? "translate-x-0" : "-translate-x-full",
        )}
      >
        <div className="border-sidebar-border border-b p-6">
          <Link href={ROUTES.PROVIDER_HOME} className="gradient-brand-text text-xl font-bold">
            Bookento Pro
          </Link>
          <p className="text-muted-foreground mt-1 text-xs">Provider Dashboard</p>
        </div>
        <nav className="flex-1 space-y-1 overflow-y-auto p-4">
          {sidebarItems.map(({ href, label, icon: Icon }) => {
            const active = pathname === href || pathname.startsWith(`${href}/`);
            return (
              <Link
                key={href}
                href={href}
                onClick={() => setSidebarOpen(false)}
                className={cn(
                  "flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm font-medium transition-colors",
                  active
                    ? "bg-sidebar-accent text-sidebar-accent-foreground"
                    : "text-muted-foreground hover:bg-sidebar-accent/50 hover:text-foreground",
                )}
              >
                <Icon className="size-4" />
                {label}
              </Link>
            );
          })}
        </nav>
      </aside>
    </>
  );
}

export function ProviderHeader({ title }) {
  const { toggleSidebar } = useUIStore();
  return (
    <header className="border-border bg-background/80 sticky top-0 z-30 border-b backdrop-blur-xl">
      <div className="flex h-14 items-center gap-4 px-4 lg:px-6">
        <button onClick={toggleSidebar} className="rounded-lg p-2 hover:bg-accent lg:hidden">
          <svg className="size-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
          </svg>
        </button>
        <h1 className="text-lg font-semibold">{title}</h1>
      </div>
    </header>
  );
}
