"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import {
  Calendar, Film, Home, MessageCircle, Search, User,
} from "lucide-react";

import { ROUTES } from "@/constants/routes.constants";
import { cn } from "@/lib/utils";

const navItems = [
  { href: ROUTES.HOME, label: "Home", icon: Home },
  { href: ROUTES.PROVIDERS, label: "Explore", icon: Search },
  { href: ROUTES.REELS, label: "Reels", icon: Film },
  { href: ROUTES.APPOINTMENTS, label: "Bookings", icon: Calendar },
  { href: ROUTES.PROFILE, label: "Profile", icon: User },
];

export function UserBottomNav() {
  const pathname = usePathname();

  return (
    <nav className="border-border bg-background/80 safe-bottom fixed inset-x-0 bottom-0 z-40 border-t backdrop-blur-xl md:hidden">
      <div className="mx-auto flex max-w-lg items-center justify-around px-2 py-2">
        {navItems.map(({ href, label, icon: Icon }) => {
          const active = pathname === href || (href !== ROUTES.HOME && pathname.startsWith(href));
          return (
            <Link
              key={href}
              href={href}
              className={cn(
                "flex flex-col items-center gap-0.5 rounded-xl px-3 py-1.5 text-xs transition-colors",
                active ? "text-primary font-medium" : "text-muted-foreground",
              )}
            >
              <Icon className={cn("size-5", active && "text-primary")} />
              {label}
            </Link>
          );
        })}
      </div>
    </nav>
  );
}

export function UserHeader({ title, showSearch = false }) {
  return (
    <header className="border-border bg-background/80 safe-top sticky top-0 z-30 border-b backdrop-blur-xl">
      <div className="mx-auto flex h-14 max-w-7xl items-center justify-between px-4">
        <h1 className="gradient-brand-text text-xl font-bold">{title || "Bookento"}</h1>
        <div className="flex items-center gap-2">
          <Link href={ROUTES.CHATS} className="text-muted-foreground hover:text-foreground rounded-xl p-2 transition-colors">
            <MessageCircle className="size-5" />
          </Link>
          <Link href={ROUTES.NOTIFICATIONS} className="text-muted-foreground hover:text-foreground rounded-xl p-2 transition-colors">
            <span className="relative">
              <Calendar className="size-5" />
              <span className="bg-destructive absolute -right-1 -top-1 size-2 rounded-full" />
            </span>
          </Link>
        </div>
      </div>
    </header>
  );
}
