import { APPOINTMENT_STATUS } from "@/constants/status.constants";
import { avatarUrl, generateId, isoDate, personName, timeSlot } from "./helpers";
import { mockProviders } from "./providers";
import { services } from "./services";
import { currentUser } from "./users";

const STATUSES = Object.values(APPOINTMENT_STATUS);

export const appointments = Array.from({ length: 30 }, (_, i) => {
  const provider = mockProviders[i % mockProviders.length];
  const service = services[i % services.length];
  const status = STATUSES[i % STATUSES.length];
  const date = new Date();
  date.setDate(date.getDate() + (i % 10) - 3);
  return {
    id: generateId("apt", i + 1),
    userId: currentUser.id,
    userName: currentUser.name,
    providerId: provider.id,
    providerName: provider.businessName,
    providerAvatar: provider.avatar,
    serviceId: service.id,
    serviceName: service.name,
    serviceIds: [service.id],
    packageId: null,
    visitType: ["onsite", "home", "online"][i % 3],
    status,
    scheduledDate: date.toISOString().split("T")[0],
    scheduledTime: timeSlot(9 + (i % 10)),
    duration: service.duration,
    amount: service.price,
    paymentMethod: ["upi", "wallet", "card"][i % 3],
    paymentStatus: status === "cancelled" ? "refunded" : "paid",
    address: i % 3 === 1 ? "123 Home Street, Mumbai" : null,
    notes: i % 4 === 0 ? "Please call before arriving" : "",
    createdAt: isoDate(i * 2),
    updatedAt: isoDate(i),
  };
});

export const providerAppointments = Array.from({ length: 25 }, (_, i) => {
  const userName = personName(i);
  const service = services[i % services.length];
  const status = ["pending", "confirmed", "upcoming", "completed", "cancelled"][i % 5];
  const date = new Date();
  date.setDate(date.getDate() + (i % 7) - 2);
  return {
    id: generateId("papt", i + 1),
    userId: generateId("user", i + 1),
    userName,
    userAvatar: avatarUrl(`apt-user-${i}`),
    userPhone: `+91 9${String(800000000 + i).slice(0, 9)}`,
    providerId: mockProviders[0].id,
    serviceName: service.name,
    serviceIds: [service.id],
    visitType: ["onsite", "home", "online"][i % 3],
    status,
    scheduledDate: date.toISOString().split("T")[0],
    scheduledTime: timeSlot(8 + (i % 12)),
    duration: service.duration,
    amount: service.price,
    paymentStatus: "paid",
    createdAt: isoDate(i),
  };
});

export const timeSlots = Array.from({ length: 16 }, (_, i) => ({
  id: generateId("slot", i + 1),
  time: timeSlot(9 + i),
  available: i % 5 !== 0,
}));

export function getAppointmentById(id) {
  return appointments.find((a) => a.id === id) || providerAppointments.find((a) => a.id === id);
}

export function getUserAppointments(userId) {
  return appointments.filter((a) => a.userId === userId);
}

export function getProviderAppointments(providerId) {
  return providerAppointments.filter((a) => a.providerId === providerId);
}

export function getPendingAppointments() {
  return providerAppointments.filter((a) => a.status === "pending");
}
