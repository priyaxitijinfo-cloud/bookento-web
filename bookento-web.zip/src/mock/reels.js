import { generateId, imageUrl, isoDate } from "./helpers";
import { mockProviders } from "./providers";

export const reels = Array.from({ length: 20 }, (_, i) => {
  const provider = mockProviders[i % 20];
  return {
    id: generateId("reel", i + 1),
    providerId: provider.id,
    providerName: provider.businessName,
    providerAvatar: provider.avatar,
    videoUrl: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    thumbnailUrl: imageUrl(`reel-${i}`, 400, 700),
    caption: `Amazing ${provider.specialty} transformation! Book now for exclusive offers. ✨`,
    hashtags: ["#bookento", "#trending", `#${provider.specialty.replace(/\s/g, "")}`],
    likes: 120 + (i % 500),
    comments: 10 + (i % 80),
    shares: 5 + (i % 30),
    views: 1000 + (i % 5000),
    isLiked: i % 3 === 0,
    linkedPackageId: i % 3 === 0 ? `pkg_${String(i + 1).padStart(4, "0")}` : null,
    linkedServiceId: i % 2 === 0 ? `svc_${String(i + 1).padStart(4, "0")}` : null,
    createdAt: isoDate(i * 2),
  };
});

export function getReelById(id) {
  return reels.find((r) => r.id === id);
}
