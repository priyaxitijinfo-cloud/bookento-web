import { generateId, isoDate, personName, avatarUrl } from "./helpers";

export const mockUsers = Array.from({ length: 30 }, (_, i) => {
  const name = personName(i);
  return {
    id: generateId("user", i + 1),
    email: `${name.toLowerCase().replace(" ", ".")}@email.com`,
    name,
    phone: `+91 9${String(800000000 + i).slice(0, 9)}`,
    avatar: avatarUrl(`user-${i}`),
    gender: i % 2 === 0 ? "male" : "female",
    role: "user",
    isVerified: true,
    walletBalance: 500 + i * 150,
    referralCode: `REF${1000 + i}`,
    totalBookings: 3 + (i % 20),
    memberSince: isoDate(365 + i * 10),
    dateOfBirth: isoDate(8000 + i * 100).split("T")[0],
    bio: "Love discovering great local services and sharing honest reviews.",
    preferences: {
      language: "en",
      notifications: true,
      marketing: i % 3 === 0,
      darkMode: false,
    },
  };
});

export const currentUser = {
  ...mockUsers[0],
  email: "abc@test.com",
  name: "Alex Sharma",
  phone: "+91 98765 43210",
};

export const userAddresses = Array.from({ length: 12 }, (_, i) => ({
  id: generateId("addr", i + 1),
  userId: currentUser.id,
  label: ["Home", "Office", "Other"][i % 3],
  name: currentUser.name,
  phone: currentUser.phone,
  addressLine1: `${100 + i * 10}, Park Avenue`,
  addressLine2: i % 2 === 0 ? "Near City Mall" : "",
  city: ["Mumbai", "Delhi", "Bangalore", "Pune"][i % 4],
  state: ["Maharashtra", "Delhi", "Karnataka", "Maharashtra"][i % 4],
  country: "India",
  pincode: String(400001 + i),
  isDefault: i === 0,
  latitude: 19.076 + i * 0.01,
  longitude: 72.877 + i * 0.01,
}));

export const savedProviders = Array.from({ length: 15 }, (_, i) => ({
  id: generateId("saved", i + 1),
  providerId: `provider_${String(i + 1).padStart(4, "0")}`,
  savedAt: isoDate(i * 3),
}));

export const walletTransactions = Array.from({ length: 25 }, (_, i) => ({
  id: generateId("wtxn", i + 1),
  type: i % 3 === 0 ? "credit" : "debit",
  amount: 100 + (i % 10) * 250,
  description: i % 3 === 0 ? "Added money to wallet" : `Payment for booking #${1000 + i}`,
  status: "completed",
  createdAt: isoDate(i * 2),
}));

export const referrals = Array.from({ length: 12 }, (_, i) => ({
  id: generateId("ref", i + 1),
  name: personName(i + 20),
  email: `friend${i}@email.com`,
  status: ["pending", "completed", "completed"][i % 3],
  reward: i % 3 === 2 ? 100 : 0,
  joinedAt: isoDate(i * 5),
}));

export function getUserById(id) {
  return mockUsers.find((u) => u.id === id);
}
