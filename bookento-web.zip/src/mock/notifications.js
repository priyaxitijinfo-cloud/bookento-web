import { generateId, isoDate } from "./helpers";

export const notifications = Array.from({ length: 25 }, (_, i) => ({
  id: generateId("notif", i + 1),
  type: ["booking", "payment", "promo", "chat", "system", "review"][i % 6],
  title: [
    "Booking Confirmed",
    "Payment Received",
    "Special Offer!",
    "New Message",
    "Account Update",
    "New Review",
  ][i % 6],
  message: [
    "Your appointment with Elite Studio is confirmed for tomorrow at 2 PM.",
    "Payment of ₹1,299 received successfully.",
    "Get 20% off on your next booking. Limited time offer!",
    "You have a new message from Premium Spa.",
    "Your profile has been updated successfully.",
    "You received a 5-star review from Alex Sharma.",
  ][i % 6],
  isRead: i > 5,
  actionUrl: ["/appointments", "/wallet", "/providers", "/chats", "/profile", "/provider/ratings"][i % 6],
  createdAt: isoDate(i),
}));

export const providerNotifications = Array.from({ length: 20 }, (_, i) => ({
  id: generateId("pnotif", i + 1),
  type: ["booking", "payment", "chat", "review", "system"][i % 5],
  title: [
    "New Booking Request",
    "Payout Processed",
    "Customer Message",
    "New 5-Star Review",
    "Profile Verified",
  ][i % 5],
  message: [
    "New booking request from Alex Sharma for Haircut & Styling.",
    "₹15,000 has been transferred to your bank account.",
    "Alex Sharma sent you a message.",
    "You received a glowing 5-star review!",
    "Your business profile is now verified.",
  ][i % 5],
  isRead: i > 4,
  actionUrl: ["/provider/appointments", "/provider/earnings", "/provider/chats", "/provider/ratings", "/provider/profile"][i % 5],
  createdAt: isoDate(i),
}));
