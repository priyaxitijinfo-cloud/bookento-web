import { avatarUrl, generateId, isoDate, personName } from "./helpers";
import { mockProviders } from "./providers";
import { currentUser } from "./users";

export const conversations = Array.from({ length: 15 }, (_, i) => {
  const provider = mockProviders[i % 15];
  return {
    id: generateId("conv", i + 1),
    participantId: provider.id,
    participantName: provider.businessName,
    participantAvatar: provider.avatar,
    participantRole: "provider",
    lastMessage: [
      "Your appointment is confirmed for tomorrow!",
      "Thank you for choosing our services.",
      "Is there anything else I can help with?",
      "We have a special offer this week.",
      "Your booking has been rescheduled.",
    ][i % 5],
    lastMessageAt: isoDate(i),
    unreadCount: i % 4,
    isOnline: i % 3 !== 0,
    isPinned: i < 2,
  };
});

export const messages = {};

conversations.forEach((conv, ci) => {
  messages[conv.id] = Array.from({ length: 12 + (ci % 8) }, (_, i) => {
    const isUser = i % 2 === 0;
    return {
      id: generateId("msg", ci * 100 + i + 1),
      conversationId: conv.id,
      senderId: isUser ? currentUser.id : conv.participantId,
      content: isUser
        ? ["Hi, I'd like to book an appointment.", "What are your available slots?", "That works for me!", "Thank you!"][i % 4]
        : ["Hello! How can I help you today?", "We have slots at 2 PM and 4 PM.", "Great! I've confirmed your booking.", "You're welcome! See you soon."][i % 4],
      type: "text",
      status: ["sent", "delivered", "seen"][Math.min(i % 3, 2)],
      createdAt: isoDate(ci + i),
      replyToId: i === 2 ? generateId("msg", ci * 100 + 1) : null,
      reactions: i % 5 === 0 ? [{ emoji: "👍", userId: conv.participantId }] : [],
    };
  });
});

export const providerConversations = Array.from({ length: 12 }, (_, i) => ({
  id: generateId("pconv", i + 1),
  participantId: generateId("user", i + 1),
  participantName: personName(i),
  participantAvatar: avatarUrl(`pconv-${i}`),
  participantRole: "user",
  lastMessage: "When is my next appointment?",
  lastMessageAt: isoDate(i),
  unreadCount: i % 3,
  isOnline: i % 2 === 0,
}));

providerConversations.forEach((conv, ci) => {
  messages[conv.id] = Array.from({ length: 10 }, (_, i) => ({
    id: generateId("pmsg", ci * 100 + i + 1),
    conversationId: conv.id,
    senderId: i % 2 === 0 ? conv.participantId : mockProviders[0].id,
    content: i % 2 === 0 ? "Hi, I have a question about my booking." : "Sure, how can I assist you?",
    type: "text",
    status: "seen",
    createdAt: isoDate(ci + i),
  }));
});

export function getConversationById(id) {
  return conversations.find((c) => c.id === id) || providerConversations.find((c) => c.id === id);
}

export function getMessages(conversationId) {
  return messages[conversationId] || [];
}
