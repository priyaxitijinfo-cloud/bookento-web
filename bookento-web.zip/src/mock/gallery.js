import { generateId, imageUrl } from "./helpers";
import { mockProviders } from "./providers";

export const gallery = {};

mockProviders.slice(0, 20).forEach((provider, pi) => {
  gallery[provider.id] = Array.from({ length: 8 + (pi % 5) }, (_, i) => ({
    id: generateId("gal", pi * 10 + i + 1),
    providerId: provider.id,
    url: imageUrl(`gallery-${provider.id}-${i}`, 600, 400),
    caption: `Gallery image ${i + 1}`,
    type: i % 5 === 0 ? "video" : "image",
    sortOrder: i + 1,
  }));
});

export function getGalleryByProvider(providerId) {
  return gallery[providerId] || [];
}
