import { avatarUrl, generateId, isoDate, personName, reviewComment } from "./helpers";
import { mockProviders } from "./providers";

export const ratingsOverview = {
  averageRating: 4.7,
  totalRatings: 1248,
  distribution: { 5: 820, 4: 312, 3: 78, 2: 25, 1: 13 },
};

export const reviews = Array.from({ length: 30 }, (_, i) => {
  const provider = mockProviders[i % mockProviders.length];
  const userName = personName(i + 10);
  return {
    id: generateId("rev", i + 1),
    providerId: provider.id,
    userId: generateId("user", i + 1),
    userName,
    userAvatar: avatarUrl(`reviewer-${i}`),
    rating: 3 + (i % 3),
    comment: reviewComment(i),
    likes: 5 + (i % 50),
    isLiked: i % 4 === 0,
    reply: i % 5 === 0 ? {
      id: generateId("reply", i + 1),
      comment: "Thank you for your wonderful feedback! We look forward to serving you again.",
      createdAt: isoDate(i - 1),
    } : null,
    createdAt: isoDate(i * 3),
  };
});

export function getReviewsByProvider(providerId) {
  return reviews.filter((r) => r.providerId === providerId);
}

export function getRatingOverview(providerId) {
  const providerReviews = getReviewsByProvider(providerId);
  if (!providerReviews.length) return ratingsOverview;
  const avg = providerReviews.reduce((s, r) => s + r.rating, 0) / providerReviews.length;
  return { ...ratingsOverview, averageRating: Number(avg.toFixed(1)), totalRatings: providerReviews.length };
}
