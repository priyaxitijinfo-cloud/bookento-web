"use client";

import Link from "next/link";
import { useRouter, useSearchParams } from "next/navigation";
import { useState } from "react";
import { toast } from "sonner";

import { PasswordInput } from "@/components/forms/password-input";
import { Button } from "@/components/ui/button";
import { FormField } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { ROUTES } from "@/constants/routes.constants";
import { USER_ROLES } from "@/constants/status.constants";
import { useAuthStore } from "@/store";

export function LoginForm({ role = USER_ROLES.USER }) {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { login, loginAsGuest, isLoading } = useAuthStore();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [remember, setRemember] = useState(false);
  const [errors, setErrors] = useState({});

  const redirect = searchParams.get("redirect");
  const isProvider = role === USER_ROLES.PROVIDER;
  const homeRoute = isProvider ? ROUTES.PROVIDER_HOME : ROUTES.HOME;

  const validate = () => {
    const e = {};
    if (!email.trim()) e.email = "Email is required";
    else if (!/\S+@\S+\.\S+/.test(email)) e.email = "Enter a valid email";
    if (!password) e.password = "Password is required";
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!validate()) return;
    const result = await login(email, password, role);
    if (result.success) {
      toast.success("Welcome back!");
      router.push(redirect || homeRoute);
    }
  };

  const handleGuest = async () => {
    await loginAsGuest();
    toast.success("Continuing as guest");
    router.push(ROUTES.HOME);
  };

  return (
    <div className="w-full max-w-md space-y-6">
      <div className="text-center">
        <h1 className="gradient-brand-text text-3xl font-bold">Bookento</h1>
        <p className="text-muted-foreground mt-2">
          {isProvider ? "Sign in to your provider account" : "Welcome back! Sign in to continue"}
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-4">
        <FormField label="Email" required error={errors.email}>
          <Input
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            error={errors.email}
          />
        </FormField>

        <FormField label="Password" required error={errors.password}>
          <PasswordInput
            placeholder="Enter your password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            error={errors.password}
          />
        </FormField>

        <div className="flex items-center justify-between text-sm">
          <label className="flex items-center gap-2">
            <input type="checkbox" checked={remember} onChange={(e) => setRemember(e.target.checked)} className="rounded" />
            Remember me
          </label>
          <Link href={isProvider ? ROUTES.PROVIDER_FORGOT_PASSWORD : ROUTES.FORGOT_PASSWORD} className="text-primary hover:underline">
            Forgot password?
          </Link>
        </div>

        <Button type="submit" className="w-full" loading={isLoading}>
          Sign In
        </Button>
      </form>

      <div className="relative">
        <div className="absolute inset-0 flex items-center"><span className="border-border w-full border-t" /></div>
        <div className="relative flex justify-center text-xs uppercase"><span className="bg-background text-muted-foreground px-2">Or continue with</span></div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Button variant="outline" type="button" onClick={() => toast.info("Google sign-in coming soon")}>
          <svg className="size-4" viewBox="0 0 24 24"><path fill="currentColor" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/><path fill="currentColor" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/><path fill="currentColor" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/><path fill="currentColor" d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/></svg>
          Google
        </Button>
        <Button variant="outline" type="button" onClick={() => toast.info("Apple sign-in coming soon")}>
          <svg className="size-4" viewBox="0 0 24 24" fill="currentColor"><path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/></svg>
          Apple
        </Button>
      </div>

      {!isProvider && (
        <Button variant="ghost" className="w-full" onClick={handleGuest}>
          Continue as Guest
        </Button>
      )}

      <p className="text-muted-foreground text-center text-sm">
        {isProvider ? (
          <>New provider? <Link href={ROUTES.PROVIDER_REGISTER} className="text-primary font-medium hover:underline">Register here</Link></>
        ) : (
          <>Don&apos;t have an account? <Link href={ROUTES.PROVIDER_REGISTER} className="text-primary font-medium hover:underline">Become a Provider</Link></>
        )}
      </p>

      {isProvider ? (
        <p className="text-muted-foreground text-center text-sm">
          Looking for services? <Link href={ROUTES.USER_LOGIN} className="text-primary font-medium hover:underline">User Login</Link>
        </p>
      ) : (
        <p className="text-muted-foreground text-center text-sm">
          Are you a provider? <Link href={ROUTES.PROVIDER_LOGIN} className="text-primary font-medium hover:underline">Provider Login</Link>
        </p>
      )}
    </div>
  );
}
