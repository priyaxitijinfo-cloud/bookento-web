export default function AuthLayout({ children }) {
  return (
    <div className="bg-background flex min-h-dvh items-center justify-center p-6">
      {children}
    </div>
  );
}
