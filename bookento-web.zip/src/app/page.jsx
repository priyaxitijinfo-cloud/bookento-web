"use client";

import Image from "next/image";
import Link from "next/link";
import { ArrowRight, Sparkles } from "lucide-react";

import { UserBottomNav, UserHeader } from "@/components/layout/user-nav";
import { ProviderCard, ProviderCardCompact } from "@/components/shared/provider-card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ROUTES, providerDetailRoute } from "@/constants/routes.constants";
import { categories } from "@/mock/categories";
import { getActiveBanners } from "@/mock/banners";
import { getFeaturedPackages } from "@/mock/packages";
import { getPopularServices } from "@/mock/services";
import {
  getFeaturedProviders, getNearbyProviders, getRecommendedProviders, getTrendingProviders,
} from "@/mock/providers";
import { useProviderStore } from "@/store";
import { formatCurrency } from "@/utils/format.utils";


function SectionHeader({ title, href }) {
  return (
    <div className="mb-4 flex items-center justify-between">
      <h2 className="text-lg font-semibold">{title}</h2>
      {href && (
        <Link href={href} className="text-primary flex items-center gap-1 text-sm font-medium">
          See all <ArrowRight className="size-4" />
        </Link>
      )}
    </div>
  );
}

function BannerCarousel() {
  const banners = getActiveBanners();
  return (
    <div className="scrollbar-hide -mx-4 flex gap-4 overflow-x-auto px-4 pb-2">
      {banners.map((banner) => (
        <Link key={banner.id} href={banner.actionUrl} className="block shrink-0">
          <Card className="relative h-40 w-72 overflow-hidden border-0">
            <Image src={banner.image} alt={banner.title} fill className="object-cover" />
            <div className="absolute inset-0 bg-gradient-to-r from-black/70 to-transparent p-4 flex flex-col justify-end">
              <Badge className="mb-2 w-fit">{banner.subtitle.split(" ")[0]}</Badge>
              <h3 className="text-lg font-bold text-white">{banner.title}</h3>
            </div>
          </Card>
        </Link>
      ))}
    </div>
  );
}

function CategoryGrid() {
  return (
    <div className="grid grid-cols-3 gap-3 sm:grid-cols-5 md:grid-cols-6">
      {categories.slice(0, 12).map((cat) => (
        <Link key={cat.id} href={`${ROUTES.PROVIDERS}?category=${cat.id}`} className="group text-center">
          <div className="bg-accent group-hover:bg-primary/10 mx-auto mb-2 flex size-14 items-center justify-center rounded-2xl transition-colors">
            <Sparkles className="text-primary size-6" />
          </div>
          <p className="line-clamp-2 text-xs font-medium">{cat.name}</p>
        </Link>
      ))}
    </div>
  );
}

export default function HomePage() {
  const { recentlyViewed } = useProviderStore();
  const trending = getTrendingProviders(10);
  const nearby = getNearbyProviders(10);
  const featured = getFeaturedProviders(6);
  const recommended = getRecommendedProviders(8);
  const popularServices = getPopularServices(8);
  const packages = getFeaturedPackages(6);

  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-6">
      <UserHeader />
      <main className="mx-auto max-w-7xl space-y-8 px-4 py-6">
        {/* Hero Search */}
        <section className="gradient-brand rounded-2xl p-6 text-white">
          <h1 className="text-2xl font-bold md:text-3xl">Find & Book Top Services</h1>
          <p className="mt-2 text-white/80">100+ verified providers · 50+ services near you</p>
          <Link href={ROUTES.PROVIDERS}>
            <Button variant="secondary" className="mt-4 bg-white text-primary hover:bg-white/90">
              Explore Providers
            </Button>
          </Link>
        </section>

        <section>
          <SectionHeader title="Offers & Promotions" href={ROUTES.PROVIDERS} />
          <BannerCarousel />
        </section>

        <section>
          <SectionHeader title="Categories" href={ROUTES.CATEGORIES} />
          <CategoryGrid />
        </section>

        {recentlyViewed.length > 0 && (
          <section>
            <SectionHeader title="Recently Viewed" />
            <div className="flex gap-4 overflow-x-auto pb-2">
              {recentlyViewed.map((p) => <ProviderCardCompact key={p.id} provider={p} />)}
            </div>
          </section>
        )}

        <section>
          <SectionHeader title="Trending Providers" href={ROUTES.PROVIDERS} />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {trending.slice(0, 6).map((p) => <ProviderCard key={p.id} provider={p} />)}
          </div>
        </section>

        <section>
          <SectionHeader title="Nearby You" href={ROUTES.PROVIDERS} />
          <div className="flex gap-4 overflow-x-auto pb-2">
            {nearby.map((p) => (
              <div key={p.id} className="w-64 shrink-0">
                <ProviderCard provider={p} />
              </div>
            ))}
          </div>
        </section>

        <section>
          <SectionHeader title="Popular Services" href={ROUTES.PROVIDERS} />
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
            {popularServices.map((svc) => (
              <Link key={svc.id} href={providerDetailRoute(svc.providerId)}>
                <Card className="overflow-hidden p-0 transition-shadow hover:shadow-card-hover">
                  <div className="relative aspect-video">
                    <Image src={svc.image} alt={svc.name} fill className="object-cover" />
                  </div>
                  <div className="p-3">
                    <p className="line-clamp-1 font-medium">{svc.name}</p>
                    <p className="text-muted-foreground text-xs">{svc.providerName}</p>
                    <p className="text-primary mt-1 text-sm font-semibold">{formatCurrency(svc.price)}</p>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <SectionHeader title="Featured Packages" href={ROUTES.PROVIDERS} />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {packages.map((pkg) => (
              <Link key={pkg.id} href={providerDetailRoute(pkg.providerId)}>
                <Card className="overflow-hidden p-0">
                  <div className="relative aspect-[16/9]">
                    <Image src={pkg.image} alt={pkg.name} fill className="object-cover" />
                    <Badge className="absolute right-2 top-2">{pkg.discountPercent}% OFF</Badge>
                  </div>
                  <div className="p-4">
                    <h3 className="font-semibold">{pkg.name}</h3>
                    <p className="text-muted-foreground text-sm line-clamp-2">{pkg.description}</p>
                    <div className="mt-2 flex items-center gap-2">
                      <span className="text-primary font-bold">{formatCurrency(pkg.price)}</span>
                      <span className="text-muted-foreground text-sm line-through">{formatCurrency(pkg.originalPrice)}</span>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </section>

        <section>
          <SectionHeader title="Recommended For You" href={ROUTES.PROVIDERS} />
          <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
            {recommended.map((p) => <ProviderCard key={p.id} provider={p} />)}
          </div>
        </section>
      </main>
      <UserBottomNav />
    </div>
  );
}
