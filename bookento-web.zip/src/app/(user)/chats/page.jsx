"use client";

import Link from "next/link";
import { useMemo, useState } from "react";
import { MessageCircle, Pin, Search } from "lucide-react";

import { UserBottomNav, UserHeader } from "@/components/layout/user-nav";
import { SearchInput } from "@/components/forms/search-input";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { chatDetailRoute } from "@/constants/routes.constants";
import { useChatStore, useFilterStore } from "@/store";
import { formatRelativeTime } from "@/utils/format.utils";
import { cn } from "@/lib/utils";

export default function ChatsPage() {
  const { conversations } = useChatStore();
  const { chatFilter, setChatFilter } = useFilterStore();
  const [search, setSearch] = useState("");

  const filtered = useMemo(() => {
    let list = [...conversations];

    if (chatFilter === "unread") {
      list = list.filter((c) => c.unreadCount > 0);
    } else if (chatFilter === "pinned") {
      list = list.filter((c) => c.isPinned);
    }

    if (search.trim()) {
      const q = search.toLowerCase();
      list = list.filter(
        (c) =>
          c.participantName.toLowerCase().includes(q) ||
          c.lastMessage.toLowerCase().includes(q),
      );
    }

    return list.sort((a, b) => {
      if (a.isPinned !== b.isPinned) return a.isPinned ? -1 : 1;
      return new Date(b.lastMessageAt) - new Date(a.lastMessageAt);
    });
  }, [conversations, chatFilter, search]);

  const unreadTotal = conversations.reduce((sum, c) => sum + c.unreadCount, 0);

  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-6">
      <UserHeader title="Messages" />
      <main className="mx-auto max-w-3xl px-4 py-6">
        <SearchInput
          placeholder="Search conversations..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="mb-4"
        />

        <div className="mb-4 flex gap-2">
          {[
            { value: "all", label: "All" },
            { value: "unread", label: `Unread (${unreadTotal})` },
            { value: "pinned", label: "Pinned" },
          ].map(({ value, label }) => (
            <button
              key={value}
              type="button"
              onClick={() => setChatFilter(value)}
              className={cn(
                "rounded-full px-4 py-1.5 text-sm font-medium transition-colors",
                chatFilter === value
                  ? "bg-primary text-primary-foreground"
                  : "bg-muted text-muted-foreground hover:bg-muted/80",
              )}
            >
              {label}
            </button>
          ))}
        </div>

        {filtered.length === 0 ? (
          <EmptyState
            icon={MessageCircle}
            title="No conversations"
            description="Start chatting with providers after booking an appointment."
          />
        ) : (
          <div className="space-y-2">
            {filtered.map((conv) => (
              <Link key={conv.id} href={chatDetailRoute(conv.id)}>
                <Card className="transition-shadow hover:shadow-card-hover">
                  <div className="flex items-center gap-3 p-4">
                    <div className="relative">
                      <Avatar src={conv.participantAvatar} name={conv.participantName} size="lg" />
                      {conv.isOnline && (
                        <span className="border-background absolute bottom-0 right-0 size-3 rounded-full border-2 bg-success" />
                      )}
                    </div>
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center justify-between gap-2">
                        <div className="flex items-center gap-1.5">
                          {conv.isPinned && <Pin className="text-primary size-3 shrink-0" />}
                          <p className="truncate font-semibold">{conv.participantName}</p>
                        </div>
                        <span className="text-muted-foreground shrink-0 text-xs">
                          {formatRelativeTime(conv.lastMessageAt)}
                        </span>
                      </div>
                      <div className="mt-1 flex items-center justify-between gap-2">
                        <p className="text-muted-foreground truncate text-sm">{conv.lastMessage}</p>
                        {conv.unreadCount > 0 && (
                          <Badge className="shrink-0 size-5 justify-center rounded-full p-0 text-xs">
                            {conv.unreadCount}
                          </Badge>
                        )}
                      </div>
                    </div>
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        )}
      </main>
      <UserBottomNav />
    </div>
  );
}
