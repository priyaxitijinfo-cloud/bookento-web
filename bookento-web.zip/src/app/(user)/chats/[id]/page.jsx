"use client";

import Link from "next/link";
import { useParams, useRouter } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft, MoreVertical, Phone, Send, Video,
} from "lucide-react";

import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { EmptyState } from "@/components/shared/empty-state";
import { ROUTES } from "@/constants/routes.constants";
import { getConversationById } from "@/mock/chat";
import { currentUser } from "@/mock/users";
import { useChatStore } from "@/store";
import { formatRelativeTime } from "@/utils/format.utils";
import { cn } from "@/lib/utils";

function TypingIndicator() {
  return (
    <div className="flex items-center gap-1 rounded-2xl bg-muted px-4 py-3">
      {[0, 1, 2].map((i) => (
        <span
          key={i}
          className="bg-muted-foreground size-2 animate-bounce rounded-full"
          style={{ animationDelay: `${i * 150}ms` }}
        />
      ))}
    </div>
  );
}

export default function ChatDetailPage() {
  const { id } = useParams();
  const router = useRouter();
  const messagesEndRef = useRef(null);
  const [input, setInput] = useState("");

  const {
    activeConversation,
    messages,
    isTyping,
    isLoading,
    setActiveConversation,
    sendMessage,
  } = useChatStore();

  const conversation = getConversationById(id);

  useEffect(() => {
    if (conversation) {
      setActiveConversation(conversation);
    }
  }, [conversation, setActiveConversation]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  if (!conversation) {
    return (
      <div className="flex min-h-dvh items-center justify-center p-6">
        <EmptyState title="Conversation not found" actionLabel="Back to chats" onAction={() => router.push(ROUTES.CHATS)} />
      </div>
    );
  }

  const handleSend = async (e) => {
    e.preventDefault();
    if (!input.trim()) return;
    const text = input.trim();
    setInput("");
    await sendMessage(text);
  };

  const displayMessages = activeConversation?.id === conversation.id ? messages : [];

  return (
    <div className="bg-background flex h-dvh flex-col">
      {/* Header */}
      <header className="border-border safe-top sticky top-0 z-30 flex items-center gap-3 border-b px-4 py-3">
        <Button variant="ghost" size="icon" onClick={() => router.push(ROUTES.CHATS)}>
          <ArrowLeft />
        </Button>
        <Avatar src={conversation.participantAvatar} name={conversation.participantName} size="md" />
        <div className="min-w-0 flex-1">
          <p className="truncate font-semibold">{conversation.participantName}</p>
          <p className="text-muted-foreground text-xs">
            {conversation.isOnline ? "Online" : "Offline"}
          </p>
        </div>
        <Link href={ROUTES.CALL_AUDIO}>
          <Button variant="ghost" size="icon"><Phone /></Button>
        </Link>
        <Link href={ROUTES.CALL_VIDEO}>
          <Button variant="ghost" size="icon"><Video /></Button>
        </Link>
        <Button variant="ghost" size="icon"><MoreVertical /></Button>
      </header>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4">
        {isLoading ? (
          <div className="flex justify-center py-8">
            <div className="border-primary size-8 animate-spin rounded-full border-4 border-t-transparent" />
          </div>
        ) : (
          <div className="space-y-4">
            {displayMessages.map((msg) => {
              const isOwn = msg.senderId === "current_user" || msg.senderId === currentUser.id;
              return (
                <div key={msg.id} className={cn("flex", isOwn ? "justify-end" : "justify-start")}>
                  <div className={cn("max-w-[80%] space-y-1", isOwn ? "items-end" : "items-start")}>
                    <div
                      className={cn(
                        "rounded-2xl px-4 py-2.5 text-sm",
                        isOwn
                          ? "bg-primary text-primary-foreground rounded-br-md"
                          : "bg-muted rounded-bl-md",
                      )}
                    >
                      {msg.content}
                    </div>
                    <p className="text-muted-foreground px-1 text-xs">
                      {formatRelativeTime(msg.createdAt)}
                      {isOwn && msg.status && ` · ${msg.status}`}
                    </p>
                  </div>
                </div>
              );
            })}
            {isTyping && (
              <div className="flex justify-start">
                <TypingIndicator />
              </div>
            )}
            <div ref={messagesEndRef} />
          </div>
        )}
      </div>

      {/* Input */}
      <form onSubmit={handleSend} className="border-border safe-bottom border-t p-4">
        <div className="mx-auto flex max-w-3xl gap-2">
          <Input
            placeholder="Type a message..."
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="flex-1"
          />
          <Button type="submit" size="icon" disabled={!input.trim()}>
            <Send />
          </Button>
        </div>
      </form>
    </div>
  );
}
