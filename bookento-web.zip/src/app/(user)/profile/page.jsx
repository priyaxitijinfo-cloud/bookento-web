"use client";

import Link from "next/link";
import {
  Bell, ChevronRight, Gift, Heart, LogOut, MapPin, MessageCircle,
  Settings, Star, Wallet,
} from "lucide-react";
import { toast } from "sonner";

import { UserBottomNav, UserHeader } from "@/components/layout/user-nav";
import { Avatar } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ROUTES } from "@/constants/routes.constants";
import { useAuthStore, useProfileStore } from "@/store";
import { formatDate, formatPhoneNumber } from "@/utils/format.utils";

const MENU_SECTIONS = [
  {
    title: "Account",
    items: [
      { href: ROUTES.SAVED, label: "Saved Providers", icon: Heart, description: "Your favorite providers" },
      { href: ROUTES.ADDRESSES, label: "My Addresses", icon: MapPin, description: "Manage delivery locations" },
      { href: ROUTES.WALLET, label: "Wallet", icon: Wallet, description: "Balance & transactions" },
      { href: ROUTES.REVIEWS, label: "My Reviews", icon: Star, description: "Reviews you've written" },
    ],
  },
  {
    title: "Engagement",
    items: [
      { href: ROUTES.REFERRALS, label: "Refer & Earn", icon: Gift, description: "Invite friends, earn rewards" },
      { href: ROUTES.NOTIFICATIONS, label: "Notifications", icon: Bell, description: "Alerts & updates" },
      { href: ROUTES.CHATS, label: "Messages", icon: MessageCircle, description: "Chat with providers" },
    ],
  },
];

export default function ProfilePage() {
  const { profile } = useProfileStore();
  const { logout } = useAuthStore();

  const handleLogout = async () => {
    await logout();
    toast.success("Logged out successfully");
    window.location.href = ROUTES.USER_LOGIN;
  };

  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-6">
      <UserHeader title="Profile" />
      <main className="mx-auto max-w-3xl space-y-6 px-4 py-6">
        {/* Profile card */}
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <Avatar src={profile.avatar} name={profile.name} size="xl" />
              <div className="flex-1">
                <div className="flex items-center gap-2">
                  <h2 className="text-xl font-bold">{profile.name}</h2>
                  {profile.isVerified && <Badge variant="success">Verified</Badge>}
                </div>
                <p className="text-muted-foreground text-sm">{profile.email}</p>
                <p className="text-muted-foreground text-sm">{formatPhoneNumber(profile.phone)}</p>
              </div>
              <Button variant="outline" size="sm">Edit</Button>
            </div>

            <div className="mt-6 grid grid-cols-3 gap-4 border-t pt-6">
              <div className="text-center">
                <p className="text-2xl font-bold">{profile.totalBookings}</p>
                <p className="text-muted-foreground text-xs">Bookings</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">{formatDate(profile.memberSince, "MMM yyyy")}</p>
                <p className="text-muted-foreground text-xs">Member Since</p>
              </div>
              <div className="text-center">
                <p className="text-2xl font-bold">₹{profile.walletBalance}</p>
                <p className="text-muted-foreground text-xs">Wallet</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Menu sections */}
        {MENU_SECTIONS.map((section) => (
          <div key={section.title}>
            <h3 className="text-muted-foreground mb-3 text-sm font-medium uppercase tracking-wide">
              {section.title}
            </h3>
            <Card>
              <CardContent className="divide-border divide-y p-0">
                {section.items.map(({ href, label, icon: Icon, description }) => (
                  <Link
                    key={href}
                    href={href}
                    className="hover:bg-muted/50 flex items-center gap-4 px-4 py-4 transition-colors"
                  >
                    <div className="bg-primary/10 flex size-10 items-center justify-center rounded-xl">
                      <Icon className="text-primary size-5" />
                    </div>
                    <div className="min-w-0 flex-1">
                      <p className="font-medium">{label}</p>
                      <p className="text-muted-foreground truncate text-sm">{description}</p>
                    </div>
                    <ChevronRight className="text-muted-foreground size-5 shrink-0" />
                  </Link>
                ))}
              </CardContent>
            </Card>
          </div>
        ))}

        <Card>
          <CardContent className="p-0">
            <button
              type="button"
              className="hover:bg-muted/50 flex w-full items-center gap-4 px-4 py-4 transition-colors"
            >
              <div className="bg-muted flex size-10 items-center justify-center rounded-xl">
                <Settings className="text-muted-foreground size-5" />
              </div>
              <span className="flex-1 text-left font-medium">Settings</span>
              <ChevronRight className="text-muted-foreground size-5" />
            </button>
          </CardContent>
        </Card>

        <Button variant="destructive" className="w-full" onClick={handleLogout}>
          <LogOut className="size-4" /> Log Out
        </Button>
      </main>
      <UserBottomNav />
    </div>
  );
}
