"use client";

import Image from "next/image";
import Link from "next/link";
import {
  Activity, Apple, BookOpen, Bug, Calculator, Camera, Car, Dumbbell,
  Hammer, Hand, Heart, Home, Leaf, Paintbrush, Palette, PartyPopper,
  PawPrint, Scale, Scissors, Settings, Shirt, Smartphone, Sofa, Sparkles,
  TreePine, Utensils, Wind, Wrench, Zap,
} from "lucide-react";

import { UserBottomNav, UserHeader } from "@/components/layout/user-nav";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { ROUTES } from "@/constants/routes.constants";
import { categories } from "@/mock/categories";

const ICON_MAP = {
  Scissors, Sparkles, Heart, Dumbbell, Leaf, Home, Wrench, Zap,
  Wind, Bug, Palette, Hand, Activity, Apple, PawPrint, Car,
  Sofa, Camera, BookOpen, Scale, Calculator, PartyPopper, Utensils,
  Shirt, TreePine, Paintbrush, Hammer, Settings, Smartphone,
};

export default function CategoriesPage() {
  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-6">
      <UserHeader title="Categories" />
      <main className="mx-auto max-w-7xl px-4 py-6">
        <div className="gradient-brand mb-8 rounded-2xl p-6 text-white">
          <h2 className="text-xl font-bold">Browse All Services</h2>
          <p className="mt-1 text-white/80">Explore {categories.length} categories with verified providers near you</p>
        </div>

        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5">
          {categories.map((cat) => {
            const Icon = ICON_MAP[cat.icon] || Sparkles;
            return (
              <Link key={cat.id} href={`${ROUTES.PROVIDERS}?category=${cat.id}`}>
                <Card className="group h-full overflow-hidden transition-all hover:shadow-card-hover">
                  <div className="relative aspect-square overflow-hidden">
                    <Image
                      src={cat.image}
                      alt={cat.name}
                      fill
                      className="object-cover transition-transform duration-300 group-hover:scale-105"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                    <div className="absolute bottom-3 left-3">
                      <div className="mb-2 flex size-10 items-center justify-center rounded-xl bg-white/20 backdrop-blur">
                        <Icon className="size-5 text-white" />
                      </div>
                    </div>
                    {cat.isFeatured && (
                      <Badge className="absolute right-2 top-2">Featured</Badge>
                    )}
                  </div>
                  <div className="p-4">
                    <h3 className="line-clamp-2 font-semibold">{cat.name}</h3>
                    <p className="text-muted-foreground mt-1 line-clamp-2 text-xs">{cat.description}</p>
                    <div className="text-muted-foreground mt-2 flex gap-3 text-xs">
                      <span>{cat.providerCount} providers</span>
                      <span>{cat.serviceCount} services</span>
                    </div>
                  </div>
                </Card>
              </Link>
            );
          })}
        </div>
      </main>
      <UserBottomNav />
    </div>
  );
}
