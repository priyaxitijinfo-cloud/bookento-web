"use client";

import { useState } from "react";
import { Home, MapPin, Plus, Star, Trash2 } from "lucide-react";
import { toast } from "sonner";

import { UserBottomNav, UserHeader } from "@/components/layout/user-nav";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { FormField } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Select } from "@/components/ui/select";
import { useProfileStore } from "@/store";

const LABEL_OPTIONS = [
  { value: "Home", label: "Home" },
  { value: "Office", label: "Office" },
  { value: "Other", label: "Other" },
];

const EMPTY_FORM = {
  label: "Home",
  name: "",
  phone: "",
  addressLine1: "",
  addressLine2: "",
  city: "",
  state: "",
  pincode: "",
};

export default function AddressesPage() {
  const { addresses, addAddress, profile } = useProfileStore();
  const [open, setOpen] = useState(false);
  const [form, setForm] = useState({ ...EMPTY_FORM, name: profile.name, phone: profile.phone });
  const [loading, setLoading] = useState(false);

  const updateField = (field, value) => setForm((f) => ({ ...f, [field]: value }));

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.addressLine1 || !form.city || !form.pincode) {
      toast.error("Please fill required fields");
      return;
    }
    setLoading(true);
    await addAddress({ ...form, country: "India", isDefault: addresses.length === 0 });
    setLoading(false);
    setOpen(false);
    setForm({ ...EMPTY_FORM, name: profile.name, phone: profile.phone });
    toast.success("Address added successfully");
  };

  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-6">
      <UserHeader title="My Addresses" />
      <main className="mx-auto max-w-3xl space-y-4 px-4 py-6">
        <div className="flex items-center justify-between">
          <p className="text-muted-foreground text-sm">{addresses.length} saved address{addresses.length !== 1 ? "es" : ""}</p>
          <Dialog open={open} onOpenChange={setOpen}>
            <DialogTrigger asChild>
              <Button size="sm"><Plus className="size-4" /> Add Address</Button>
            </DialogTrigger>
            <DialogContent className="max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Address</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleSubmit} className="space-y-4">
                <FormField label="Label">
                  <Select
                    value={form.label}
                    onValueChange={(v) => updateField("label", v)}
                    options={LABEL_OPTIONS}
                  />
                </FormField>
                <FormField label="Full Name" required>
                  <Input value={form.name} onChange={(e) => updateField("name", e.target.value)} />
                </FormField>
                <FormField label="Phone" required>
                  <Input value={form.phone} onChange={(e) => updateField("phone", e.target.value)} />
                </FormField>
                <FormField label="Address Line 1" required>
                  <Input value={form.addressLine1} onChange={(e) => updateField("addressLine1", e.target.value)} placeholder="House no., Street" />
                </FormField>
                <FormField label="Address Line 2">
                  <Input value={form.addressLine2} onChange={(e) => updateField("addressLine2", e.target.value)} placeholder="Landmark (optional)" />
                </FormField>
                <div className="grid grid-cols-2 gap-4">
                  <FormField label="City" required>
                    <Input value={form.city} onChange={(e) => updateField("city", e.target.value)} />
                  </FormField>
                  <FormField label="State">
                    <Input value={form.state} onChange={(e) => updateField("state", e.target.value)} />
                  </FormField>
                </div>
                <FormField label="Pincode" required>
                  <Input value={form.pincode} onChange={(e) => updateField("pincode", e.target.value)} />
                </FormField>
                <DialogFooter>
                  <Button type="button" variant="outline" onClick={() => setOpen(false)}>Cancel</Button>
                  <Button type="submit" loading={loading}>Save Address</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
        </div>

        {addresses.map((addr) => (
          <Card key={addr.id}>
            <CardContent className="pt-5">
              <div className="flex items-start justify-between gap-4">
                <div className="flex gap-3">
                  <div className="bg-primary/10 flex size-10 shrink-0 items-center justify-center rounded-xl">
                    {addr.label === "Home" ? <Home className="text-primary size-5" /> : <MapPin className="text-primary size-5" />}
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <p className="font-semibold">{addr.label}</p>
                      {addr.isDefault && <Badge variant="success">Default</Badge>}
                    </div>
                    <p className="mt-1 text-sm">{addr.name} · {addr.phone}</p>
                    <p className="text-muted-foreground mt-1 text-sm">
                      {addr.addressLine1}{addr.addressLine2 ? `, ${addr.addressLine2}` : ""}
                    </p>
                    <p className="text-muted-foreground text-sm">
                      {addr.city}, {addr.state} - {addr.pincode}
                    </p>
                  </div>
                </div>
                <div className="flex gap-1">
                  {!addr.isDefault && (
                    <Button variant="ghost" size="icon" title="Set as default">
                      <Star className="size-4" />
                    </Button>
                  )}
                  <Button variant="ghost" size="icon" title="Delete">
                    <Trash2 className="text-destructive size-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </main>
      <UserBottomNav />
    </div>
  );
}
