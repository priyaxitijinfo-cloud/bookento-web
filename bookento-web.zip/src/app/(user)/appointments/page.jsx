"use client";

import Image from "next/image";
import Link from "next/link";
import { useMemo } from "react";
import {
  Building2, Calendar, Clock, Home, MapPin, Monitor,
} from "lucide-react";

import { UserBottomNav, UserHeader } from "@/components/layout/user-nav";
import { EmptyState } from "@/components/shared/empty-state";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { APPOINTMENT_STATUS } from "@/constants/status.constants";
import { providerDetailRoute, ROUTES } from "@/constants/routes.constants";
import { appointments } from "@/mock/appointments";
import { useFilterStore } from "@/store";
import { formatCurrency, formatDate } from "@/utils/format.utils";

const VISIT_ICONS = { onsite: Building2, home: Home, online: Monitor };
const VISIT_LABELS = { onsite: "In Clinic", home: "Home Visit", online: "Online" };

const STATUS_VARIANT = {
  pending: "warning",
  confirmed: "default",
  upcoming: "default",
  completed: "success",
  cancelled: "destructive",
  rejected: "destructive",
};

const TAB_STATUS_MAP = {
  upcoming: [APPOINTMENT_STATUS.PENDING, APPOINTMENT_STATUS.CONFIRMED, APPOINTMENT_STATUS.UPCOMING],
  completed: [APPOINTMENT_STATUS.COMPLETED],
  cancelled: [APPOINTMENT_STATUS.CANCELLED, APPOINTMENT_STATUS.REJECTED],
};

function AppointmentCard({ appointment }) {
  const VisitIcon = VISIT_ICONS[appointment.visitType] || Building2;

  return (
    <Card>
      <CardContent className="pt-5">
        <div className="flex gap-4">
          <div className="relative size-16 shrink-0 overflow-hidden rounded-xl">
            <Image src={appointment.providerAvatar} alt={appointment.providerName} fill className="object-cover" />
          </div>
          <div className="min-w-0 flex-1">
            <div className="flex items-start justify-between gap-2">
              <div>
                <Link href={providerDetailRoute(appointment.providerId)} className="font-semibold hover:underline">
                  {appointment.providerName}
                </Link>
                <p className="text-muted-foreground text-sm">{appointment.serviceName}</p>
              </div>
              <Badge variant={STATUS_VARIANT[appointment.status] || "secondary"} className="capitalize shrink-0">
                {appointment.status}
              </Badge>
            </div>

            <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-sm">
              <span className="text-muted-foreground flex items-center gap-1">
                <Calendar className="size-3.5" />
                {formatDate(appointment.scheduledDate, "EEE, dd MMM yyyy")}
              </span>
              <span className="text-muted-foreground flex items-center gap-1">
                <Clock className="size-3.5" />
                {appointment.scheduledTime}
              </span>
              <span className="text-muted-foreground flex items-center gap-1">
                <VisitIcon className="size-3.5" />
                {VISIT_LABELS[appointment.visitType]}
              </span>
            </div>

            {appointment.address && (
              <p className="text-muted-foreground mt-2 flex items-start gap-1 text-xs">
                <MapPin className="mt-0.5 size-3 shrink-0" />
                {appointment.address}
              </p>
            )}

            <div className="mt-3 flex items-center justify-between border-t pt-3">
              <span className="text-primary font-semibold">{formatCurrency(appointment.amount)}</span>
              <div className="flex gap-2">
                <Link href={ROUTES.CHATS}>
                  <Button variant="outline" size="sm">Message</Button>
                </Link>
                {appointment.status === APPOINTMENT_STATUS.UPCOMING && (
                  <Button variant="ghost" size="sm">Reschedule</Button>
                )}
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

export default function AppointmentsPage() {
  const { appointmentTab, setAppointmentTab } = useFilterStore();

  const grouped = useMemo(() => ({
    upcoming: appointments.filter((a) => TAB_STATUS_MAP.upcoming.includes(a.status)),
    completed: appointments.filter((a) => TAB_STATUS_MAP.completed.includes(a.status)),
    cancelled: appointments.filter((a) => TAB_STATUS_MAP.cancelled.includes(a.status)),
  }), []);

  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-6">
      <UserHeader title="My Bookings" />
      <main className="mx-auto max-w-3xl px-4 py-6">
        <Tabs value={appointmentTab} onValueChange={setAppointmentTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="upcoming">
              Upcoming ({grouped.upcoming.length})
            </TabsTrigger>
            <TabsTrigger value="completed">
              Completed ({grouped.completed.length})
            </TabsTrigger>
            <TabsTrigger value="cancelled">
              Cancelled ({grouped.cancelled.length})
            </TabsTrigger>
          </TabsList>

          {Object.entries(grouped).map(([tab, list]) => (
            <TabsContent key={tab} value={tab} className="mt-6 space-y-4">
              {list.length === 0 ? (
                <EmptyState
                  icon={Calendar}
                  title={`No ${tab} bookings`}
                  description={`You don't have any ${tab} appointments yet.`}
                  actionLabel="Find providers"
                  onAction={() => { window.location.href = ROUTES.PROVIDERS; }}
                />
              ) : (
                list.map((apt) => <AppointmentCard key={apt.id} appointment={apt} />)
              )}
            </TabsContent>
          ))}
        </Tabs>
      </main>
      <UserBottomNav />
    </div>
  );
}
