"use client";

import Link from "next/link";
import { useMemo } from "react";
import {
  Bell, Calendar, CreditCard, MessageCircle, Star, Tag,
} from "lucide-react";

import { UserBottomNav, UserHeader } from "@/components/layout/user-nav";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { useNotificationStore } from "@/store";
import { formatRelativeTime } from "@/utils/format.utils";
import { cn } from "@/lib/utils";

const TYPE_CONFIG = {
  booking: { icon: Calendar, color: "text-primary" },
  payment: { icon: CreditCard, color: "text-success" },
  promo: { icon: Tag, color: "text-warning" },
  chat: { icon: MessageCircle, color: "text-primary" },
  system: { icon: Bell, color: "text-muted-foreground" },
  review: { icon: Star, color: "text-warning" },
};

export default function NotificationsPage() {
  const { notifications, markAsRead, markAllRead, unreadCount } = useNotificationStore();

  const sorted = useMemo(
    () => [...notifications].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt)),
    [notifications],
  );

  const unread = unreadCount("user");

  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-6">
      <UserHeader title="Notifications" />
      <main className="mx-auto max-w-3xl px-4 py-6">
        <div className="mb-4 flex items-center justify-between">
          <p className="text-muted-foreground text-sm">
            {unread > 0 ? `${unread} unread notification${unread !== 1 ? "s" : ""}` : "All caught up!"}
          </p>
          {unread > 0 && (
            <Button variant="ghost" size="sm" onClick={() => markAllRead("user")}>
              Mark all read
            </Button>
          )}
        </div>

        {sorted.length === 0 ? (
          <EmptyState icon={Bell} title="No notifications" description="You're all caught up!" />
        ) : (
          <div className="space-y-2">
            {sorted.map((notif) => {
              const config = TYPE_CONFIG[notif.type] || TYPE_CONFIG.system;
              const Icon = config.icon;
              return (
                <Link key={notif.id} href={notif.actionUrl} onClick={() => markAsRead(notif.id)}>
                  <Card className={cn(
                    "transition-shadow hover:shadow-card-hover",
                    !notif.isRead && "border-primary/30 bg-primary/5",
                  )}>
                    <div className="flex gap-4 p-4">
                      <div className={cn("bg-muted flex size-10 shrink-0 items-center justify-center rounded-xl", config.color)}>
                        <Icon className="size-5" />
                      </div>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-start justify-between gap-2">
                          <p className="font-semibold">{notif.title}</p>
                          {!notif.isRead && <Badge className="shrink-0">New</Badge>}
                        </div>
                        <p className="text-muted-foreground mt-1 text-sm">{notif.message}</p>
                        <p className="text-muted-foreground mt-2 text-xs">{formatRelativeTime(notif.createdAt)}</p>
                      </div>
                    </div>
                  </Card>
                </Link>
              );
            })}
          </div>
        )}
      </main>
      <UserBottomNav />
    </div>
  );
}
