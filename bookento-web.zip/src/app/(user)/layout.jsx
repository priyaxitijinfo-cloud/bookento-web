export default function UserLayout({ children }) {
  return (
    <div className="bg-background min-h-dvh pb-20 md:pb-0">
      {children}
    </div>
  );
}
