export const ROUTES = {
  HOME: "/",
  USER_LOGIN: "/login",
  REELS: "/reels",
  APPOINTMENTS: "/appointments",
  CHATS: "/chats",
  PROFILE: "/profile",
  SAVED: "/saved",
  ADDRESSES: "/addresses",
  WALLET: "/wallet",
  REVIEWS: "/reviews",
  REFERRALS: "/referrals",
  PROVIDERS: "/providers",
  BOOKING: "/booking",
  SEARCH: "/search",
  CATEGORIES: "/categories",
  NOTIFICATIONS: "/notifications",
  CALL_AUDIO: "/call/audio",
  CALL_VIDEO: "/call/video",

  PROVIDER_HOME: "/provider",
  PROVIDER_LOGIN: "/provider/login",
  PROVIDER_REGISTER: "/provider/register",
  PROVIDER_APPOINTMENTS: "/provider/appointments",
  PROVIDER_CHATS: "/provider/chats",
  PROVIDER_EARNINGS: "/provider/earnings",
  PROVIDER_SETTINGS: "/provider/settings",
  PROVIDER_SERVICES: "/provider/services",
  PROVIDER_BRANCHES: "/provider/branches",
  PROVIDER_PACKAGES: "/provider/packages",
  PROVIDER_POSTS: "/provider/posts",
  PROVIDER_REELS: "/provider/reels",
  PROVIDER_CATEGORIES: "/provider/categories",
  PROVIDER_RATINGS: "/provider/ratings",
  PROVIDER_PROFILE: "/provider/profile",
  PROVIDER_ANALYTICS: "/provider/analytics",
  PROVIDER_GALLERY: "/provider/gallery",
  PROVIDER_NOTIFICATIONS: "/provider/notifications",

  FORGOT_PASSWORD: "/forgot-password",
  VERIFY_OTP: "/verify-otp",
  RESET_PASSWORD: "/reset-password",
  PROVIDER_FORGOT_PASSWORD: "/provider/forgot-password",
  PROVIDER_VERIFY_OTP: "/provider/verify-otp",
  PROVIDER_RESET_PASSWORD: "/provider/reset-password",
  PROVIDER_REGISTRATION_STATUS: "/provider/registration-status",
};

export const GUEST_ROUTES = [
  ROUTES.USER_LOGIN,
  ROUTES.PROVIDER_LOGIN,
  ROUTES.PROVIDER_REGISTER,
  ROUTES.FORGOT_PASSWORD,
  ROUTES.VERIFY_OTP,
  ROUTES.RESET_PASSWORD,
  ROUTES.PROVIDER_FORGOT_PASSWORD,
  ROUTES.PROVIDER_VERIFY_OTP,
  ROUTES.PROVIDER_RESET_PASSWORD,
];

export const PROVIDER_ROUTES_PREFIX = "/provider";

export function providerDetailRoute(id) {
  return `/providers/${id}`;
}

export function providerBookingRoute(id) {
  return `/booking?provider=${id}`;
}

export function chatDetailRoute(id) {
  return `/chats/${id}`;
}
