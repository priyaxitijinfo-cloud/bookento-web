import { NextResponse } from "next/server";

import { AUTH_CONFIG } from "@/config/app.config";
import { GUEST_ROUTES, PROVIDER_ROUTES_PREFIX, ROUTES } from "@/constants/routes.constants";

const PROVIDER_PUBLIC_ROUTES = [
  ROUTES.PROVIDER_LOGIN,
  ROUTES.PROVIDER_REGISTER,
  ROUTES.PROVIDER_FORGOT_PASSWORD,
  ROUTES.PROVIDER_VERIFY_OTP,
  ROUTES.PROVIDER_RESET_PASSWORD,
  ROUTES.PROVIDER_REGISTRATION_STATUS,
];

function decodeJwtPayload(token) {
  try {
    const parts = token.split(".");
    if (parts.length !== 3) return null;
    const payload = parts[1];
    if (!payload) return null;
    const decoded = atob(payload.replace(/-/g, "+").replace(/_/g, "/"));
    return JSON.parse(decoded);
  } catch {
    return null;
  }
}

function isTokenExpired(token) {
  const payload = decodeJwtPayload(token);
  if (!payload || typeof payload.exp !== "number") return true;
  return payload.exp * 1000 < Date.now();
}

function getAuthFromRequest(request) {
  const accessToken = request.cookies.get(AUTH_CONFIG.accessTokenCookie)?.value;
  if (!accessToken || isTokenExpired(accessToken)) return null;
  const payload = decodeJwtPayload(accessToken);
  if (!payload) return null;
  return {
    role: payload.role,
    status: payload.status,
    userId: payload.sub,
  };
}

export function middleware(request) {
  const { pathname } = request.nextUrl;
  const auth = getAuthFromRequest(request);
  const isAuthenticated = !!auth;

  const isProviderRoute = pathname.startsWith(PROVIDER_ROUTES_PREFIX);
  const isGuestRoute = GUEST_ROUTES.some(
    (route) => pathname === route || pathname.startsWith(`${route}/`),
  );
  const isProviderPublicRoute = PROVIDER_PUBLIC_ROUTES.some(
    (route) => pathname === route || pathname.startsWith(`${route}/`),
  );

  if (isAuthenticated && isGuestRoute) {
    const redirectUrl = auth?.role === "provider" ? ROUTES.PROVIDER_HOME : ROUTES.HOME;
    return NextResponse.redirect(new URL(redirectUrl, request.url));
  }

  if (isProviderRoute && !isProviderPublicRoute) {
    if (!isAuthenticated) {
      const loginUrl = new URL(ROUTES.PROVIDER_LOGIN, request.url);
      loginUrl.searchParams.set("redirect", pathname);
      return NextResponse.redirect(loginUrl);
    }
    if (auth?.role !== "provider") {
      return NextResponse.redirect(new URL(ROUTES.HOME, request.url));
    }
    if (auth?.status === "rejected") {
      return NextResponse.redirect(new URL(ROUTES.PROVIDER_REGISTRATION_STATUS, request.url));
    }
    if (auth?.status === "pending" && pathname !== ROUTES.PROVIDER_REGISTRATION_STATUS) {
      return NextResponse.redirect(new URL(ROUTES.PROVIDER_REGISTRATION_STATUS, request.url));
    }
  }

  const isPublicAsset =
    pathname.startsWith("/_next") ||
    pathname.startsWith("/api") ||
    pathname.includes(".");

  if (!isProviderRoute && !isGuestRoute && !isPublicAsset && pathname !== ROUTES.HOME) {
    const protectedUserPrefixes = [
      "/appointments", "/chats", "/profile", "/saved", "/addresses",
      "/wallet", "/reviews", "/referrals", "/booking",
    ];
    const isProtectedUserRoute = protectedUserPrefixes.some((prefix) =>
      pathname.startsWith(prefix),
    );
    if (isProtectedUserRoute && !isAuthenticated) {
      const loginUrl = new URL(ROUTES.USER_LOGIN, request.url);
      loginUrl.searchParams.set("redirect", pathname);
      return NextResponse.redirect(loginUrl);
    }
    if (isProtectedUserRoute && auth?.role === "provider") {
      return NextResponse.redirect(new URL(ROUTES.PROVIDER_HOME, request.url));
    }
  }

  const response = NextResponse.next();
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("X-Frame-Options", "DENY");
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
